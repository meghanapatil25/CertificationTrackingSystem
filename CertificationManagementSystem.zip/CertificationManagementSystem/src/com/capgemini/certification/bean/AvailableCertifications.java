/*
 * Creation : 17 Apr 2019
 */
package com.capgemini.certification.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AVAILABLECERTIFICATIONS")
public class AvailableCertifications implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 7773993614014655748L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "title")
    private String title;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return "AvailableCertifications [id=" + id + ", title=" + title + "]";
    }

}
