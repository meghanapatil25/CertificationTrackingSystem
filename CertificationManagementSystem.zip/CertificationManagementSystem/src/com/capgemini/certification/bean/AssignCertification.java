/*
 * Creation : 17 Apr 2019
 */
package com.capgemini.certification.bean;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CERTIFICATIONDETAILS")
public class AssignCertification implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -5144719673336067453L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "task_id")
    private Integer id;

    @Column(name = "title")
    private String name;

    @Column(name = "start_date")
    private Date assignedDate;

    @Column(name = "start_time")
    private String assignedTime;

    @Column(name = "assigned_to")
    private String assignedTo;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getAssignedDate() {
        return assignedDate;
    }

    public void setAssignedDate(Date assignedDate) {
        this.assignedDate = assignedDate;
    }

    public String getAssignedTime() {
        return assignedTime;
    }

    public void setAssignedTime(String assignedTime) {
        this.assignedTime = assignedTime;
    }

    public String getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(String assignedTo) {
        this.assignedTo = assignedTo;
    }

    @Override
    public String toString() {
        return "AssignCertification [id=" + id + ", name=" + name + ", assignedDate=" + assignedDate + ", assignedTime=" + assignedTime
                + ", assignedTo=" + assignedTo + "]";
    }

}
