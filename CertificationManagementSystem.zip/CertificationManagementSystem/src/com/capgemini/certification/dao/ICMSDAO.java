/*
 * Creation : 14 Apr 2019
 */
package com.capgemini.certification.dao;

import java.util.List;

import com.capgemini.certification.bean.AssignCertification;
import com.capgemini.certification.bean.AvailableCertifications;
import com.capgemini.certification.bean.CertificationRequest;
import com.capgemini.certification.bean.UserDetails;

public interface ICMSDAO {

    List<UserDetails> vaidateUser(UserDetails user);

    List<UserDetails> viewAllUsers();

    void addNewUser(UserDetails user);

    List<AvailableCertifications> getAvailableCertifications();

    List<Object> getAllEmployees();

    void assignCertification(AssignCertification assign);

    List<CertificationRequest> getAllRequests();

    void approveRequest(Integer id);

    List<AssignCertification> getAssignedCertifications(String empId);

    void raiseCertifications(CertificationRequest certification);

}
